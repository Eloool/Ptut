using System;
using System.Collections.Generic;
using UnityEngine;

public class Generationterrain : MonoBehaviour
{
    [Header("Bouton")]
    private float holdTime = 0f;
    private float holdThreshold = 0.5f;
    private float repeatRate = 0.1f;

    private bool isHoldingPlus = false;
    private bool isHoldingMinus = false;


    [Header("Deformation")]
    [Range(1f, 30f)]
    public float radius = 1f;

    [Range(1f, 10f)]
    public float deformationStrength = 1f;

    [Header("Animation Curves")]
    public List<AnimationCurve> curves = new List<AnimationCurve>(); // Liste pour stocker les courbes
    private int currentCurveIndex = 0;

    public int resolution;
    public int dimension;
    private float coords;
    public double tailleCote;

    // D�claration d'un mesh statique partag�
    private static Mesh sharedMesh;

    private Vector3[] p_vertices;
    private Vector3[] p_normals;
    private int[] p_triangles;
    private MeshFilter p_meshFilter;
    private MeshCollider p_meshCollider;
    private bool CentrerPivot = true;

    // Nouveaux param�tres ajout�s
    public Camera p_cam; // R�f�rence � la cam�ra
    public LayerMask maskPickingTerrain; // Masque de calque pour le picking
    private RaycastHit hit; // Stocker le r�sultat du raycast
    private void Cr�er_Terrain(int num, float x, float y)
    {
        GameObject obj = new GameObject();
        obj.name = "Chunck " + num;
        obj.AddComponent<MeshFilter>();
        obj.AddComponent<MeshCollider>();
        obj.AddComponent<MeshRenderer>();
        obj.layer = LayerMask.NameToLayer("Chunk");

        Material blueMaterial = new Material(Shader.Find("Standard"));
        blueMaterial.color = Color.blue;
        obj.GetComponent<MeshRenderer>().material = blueMaterial;

        // Cr�ation du mesh partag� si ce n'est pas d�j� fait
        if (sharedMesh == null)
        {
            sharedMesh = new Mesh();
            sharedMesh.name = "ProceduralTerrainMESH";
            Debug.Log("Cr�ation du mesh partag�");

            p_vertices = new Vector3[resolution * resolution];
            p_normals = new Vector3[p_vertices.Length];
            p_triangles = new int[3 * 2 * resolution * resolution];
            int indice_vertex = 0;
            float distance = (float)dimension / (float)resolution;
            for (float j = 0; j < resolution; j++)
            {
                for (float i = 0; i < resolution; i++)
                {
                    p_vertices[indice_vertex] = new Vector3(i * distance, 0, j * distance);
                    p_normals[indice_vertex] = new Vector3(0, 1, 0);
                    indice_vertex++;
                }
            }

            if (CentrerPivot)
            {
                Vector3 decalCentrage = new Vector3((float)dimension / 2, 0, (float)dimension / 2);
                for (int k = 0; k < p_vertices.Length; k++)
                {
                    p_vertices[k] -= decalCentrage;
                }
            }

            int indice_triangle = 0;
            for (int j = 0; j < resolution - 1; j++)
            {
                for (int i = 0; i < resolution - 1; i++)
                {
                    p_triangles[indice_triangle + 0] = j * resolution + i;
                    p_triangles[indice_triangle + 1] = (j + 1) * resolution + i + 1;
                    p_triangles[indice_triangle + 2] = j * resolution + i + 1;
                    indice_triangle += 3;
                    p_triangles[indice_triangle + 0] = j * resolution + i;
                    p_triangles[indice_triangle + 1] = (j + 1) * resolution + i;
                    p_triangles[indice_triangle + 2] = (j + 1) * resolution + i + 1;
                    indice_triangle += 3;
                }
            }

            sharedMesh.vertices = p_vertices;
            sharedMesh.normals = p_normals;
            sharedMesh.triangles = p_triangles;
            Debug.Log("Mesh partag� configur� avec " + sharedMesh.vertexCount + " sommets.");
        }

        // Utilisation du mesh partag�
        p_meshFilter = obj.GetComponent<MeshFilter>();
        p_meshCollider = obj.GetComponent<MeshCollider>();
        obj.transform.position = new Vector3(x, 0, y);

        // Assignation correcte
        p_meshFilter.sharedMesh = sharedMesh;  // Utiliser sharedMesh ici
        p_meshCollider.sharedMesh = sharedMesh; // Assurer que le collider utilise le mesh partag�

        // S'assurer que le collider n'essaie pas de g�n�rer une instance
        p_meshCollider.convex = false; // Assurez-vous que ce n'est pas convexe, si ce n'est pas n�cessaire

        Debug.Log("Terrain cr�� avec le mesh : " + p_meshFilter.sharedMesh.name);
    }


    void Start()
    {
        maskPickingTerrain = LayerMask.GetMask("Chunk");
        p_cam = Camera.main;
        coords = dimension * (resolution - 1) / resolution;

        for (int i = 0; i < tailleCote; i++)
        {
            for (int j = 0; j < tailleCote; j++)
            {
                Cr�er_Terrain(i + j * (int)tailleCote, coords * i, coords * j);
            }
        }
    }

    void Update()
    {
        // Gestion de la d�formation au clic gauche et Ctrl + clic gauche
        if (Input.GetMouseButtonDown(0)) // Clic gauche
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);

            if (Physics.Raycast(ray, out hit, Mathf.Infinity, maskPickingTerrain))
            {
                MeshCollider meshCollider = hit.collider as MeshCollider;
                if (meshCollider != null)
                {
                    Debug.Log("Objet touch� : " + hit.collider.gameObject.name);
                    if (meshCollider.sharedMesh.name == sharedMesh.name)
                    {
                        // R�cup�rer le sommet cible
                        Vector3 targetVertex = RechercherVertexCible(hit);

                        // V�rifier si le clic est avec Ctrl pour d�terminer le type de d�formation
                        bool isDepression = Input.GetKey(KeyCode.LeftControl) || Input.GetKey(KeyCode.RightControl);

                        // Appliquer la d�formation : �l�vation ou d�pression
                        DeformerTerrain(targetVertex, isDepression);
                    }
                    else
                    {
                        Debug.Log("L'objet touch� n'est pas le maillage attendu. Maillage touch� : " + meshCollider.sharedMesh.name);
                    }
                }
            }
        }

        // Gestion des entr�es utilisateur pour l'intensit�
        if (Input.GetKey(KeyCode.LeftControl) && Input.GetKeyDown(KeyCode.LeftAlt))
        {
            deformationStrength -= 1f;
        }
        else if (Input.GetKeyDown(KeyCode.LeftAlt))
        {
            deformationStrength += 1f;
        }

        // Modification du rayon de la d�formation avec les touches + et -
        if (Input.GetKeyDown(KeyCode.Equals) || Input.GetKeyDown(KeyCode.KeypadPlus))
        {
            radius += 0.5f;
        }
        else if (Input.GetKeyDown(KeyCode.Minus) || Input.GetKeyDown(KeyCode.KeypadMinus))
        {
            radius -= 0.5f;
        }

        // Changement de pattern avec la touche P
        if (Input.GetKeyDown(KeyCode.P))
        {
            currentCurveIndex = (currentCurveIndex + 1) % curves.Count;
            Debug.Log("Pattern chang� : " + currentCurveIndex);
        }
    }

    private void DeformerTerrain(Vector3 targetVertex, bool Depression)
    {

        // Calcul de la force de d�formation (positive ou n�gative)
        float deformationBase = deformationStrength * (Depression ? -1 : 1);

        // R�cup�rer les voisins pour appliquer la d�formation
        List<Voisin> voisins = RechercherVoisins(targetVertex, radius);

        // Utiliser la courbe d'animation actuelle pour la d�formation
        AnimationCurve currentCurve = curves[currentCurveIndex];

        // Appliquer la d�formation en fonction de la distance et de la courbe d'animation
        foreach (Voisin voisin in voisins)
        {
            // Calculer la distance relative (0 = sommet cible, 1 = bord du rayon)
            float relativeDistance = Mathf.Clamp01(voisin.distance / radius);

            // Obtenir la force de la courbe d'animation en fonction de la distance relative
            float curveFactor = currentCurve.Evaluate(relativeDistance);

            // Appliquer la d�formation modifi�e par la courbe
            float deformation = deformationBase * curveFactor;
            p_vertices[voisin.indice].y += deformation;
        }

        // Mettre � jour le mesh avec les nouveaux vertices d�form�s
        sharedMesh.vertices = p_vertices;
        sharedMesh.RecalculateNormals();

    }
    private Vector3 RechercherVertexCible(RaycastHit hit)
    {
        Vector3 closestVertex = Vector3.zero;
        float minDistance = float.MaxValue;

        // R�cup�rer l'indice du triangle touch� par le Raycast
        int triangleIndex = hit.triangleIndex;

        // V�rifiez si l'indice du triangle est valide
        if (triangleIndex < 0 || triangleIndex * 3 + 2 >= sharedMesh.triangles.Length)
        {
            Debug.LogWarning("Indice de triangle invalide ou hors des limites.");
            return closestVertex;
        }

        int[] triangleVertices = new int[] {
            sharedMesh.triangles[triangleIndex * 3],
            sharedMesh.triangles[triangleIndex * 3 + 1],
            sharedMesh.triangles[triangleIndex * 3 + 2]
        };

        // Trouver le vertex le plus proche parmi les trois du triangle
        foreach (int vertexIndex in triangleVertices)
        {
            if (vertexIndex < 0 || vertexIndex >= p_vertices.Length)
            {
                Debug.LogWarning("Indice de vertex invalide ou hors des limites.");
                continue;
            }

            Vector3 vertexPosition = p_vertices[vertexIndex];
            float distance = Vector3.Distance(hit.point, vertexPosition);
            if (distance < minDistance)
            {
                minDistance = distance;
                closestVertex = vertexPosition;
            }
        }

        return closestVertex;
    }

    private List<Voisin> RechercherVoisins(Vector3 cible, float radius)
    {
        List<Voisin> voisins = new List<Voisin>();

        // Ici, nous it�rons sur les sommets et r�cup�rons les voisins
        for (int i = 0; i < p_vertices.Length; i++)
        {
            Vector3 vertex = p_vertices[i];
            float distance = Vector3.Distance(vertex, cible);
            if (distance <= radius)
            {
                voisins.Add(new Voisin { indice = i, distance = distance });
            }
        }

        return voisins;
    }
}

[Serializable]
public class Voisin
{
    public int indice;
    public float distance;
}
