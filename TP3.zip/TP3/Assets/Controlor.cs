using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.XR;

public class Controlor : MonoBehaviour
{
    //public Canvas canvas;
    public Slider SliderDimention;
    public Slider SliderResolution;
    public Canvas Canvasinst;
    private FlyCamera flyCamera; // R�f�rence au script FlyCamera
    private bool isPanelActive = false;
    void Start()
    {
        // Canvasinst = Instantiate(canvas);
        Canvasinst.enabled = true;
        Canvasinst.worldCamera = Camera.main;
        Canvasinst.planeDistance = 0.5f;
        Canvasinst.gameObject.SetActive(false);
        print("SliderDimention  " + SliderDimention.value);
        print("SliderResolution  " + SliderResolution.value);

        // Trouver le script FlyCamera attach� � la cam�ra
        flyCamera = Camera.main.GetComponent<FlyCamera>();
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.F10))
        {
            isPanelActive = !isPanelActive;
            Canvasinst.gameObject.SetActive(isPanelActive);

            // Bloquer ou d�bloquer les mouvements de la cam�ra
            if (flyCamera != null)
            {
                flyCamera.canMove = !isPanelActive;  // Bloquer la cam�ra si le panel est actif
            }
        }

    }

}

